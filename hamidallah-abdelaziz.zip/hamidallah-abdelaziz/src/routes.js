/*!

=========================================================
* Paper Dashboard React - v1.3.0
=========================================================

* Product Page: https://www.creative-tim.com/product/paper-dashboard-react
* Copyright 2021 Creative Tim (https://www.creative-tim.com)

* Licensed under MIT (https://github.com/creativetimofficial/paper-dashboard-react/blob/main/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/
import Bilan from "views/Bilan";
import Dashboard from "views/Dashboard.js";
import Operation1 from "views/Operation1";
import Operation2 from "views/Operation2";

var routes = [
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: "nc-icon nc-bank",
    component: Dashboard,
    layout: "/admin",
  },
  {
    path: "/operation1",
    name: "Operation1",
    icon: "fas fa-chart-area",
    component: Operation1,
    layout: "/admin",
  },
  {
    path: "/operation2",
    name: "Operation2",
    icon: "fas fa-chart-bar",
    component: Operation2,
    layout: "/admin",
  },
  {
    path: "/bilan",
    name: "Bilan",
    icon: "fas fa-chart-line",
    component: Bilan,
    layout: "/admin",
  },
];
export default routes;
