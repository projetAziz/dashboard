import React from "react";
import { Row, Col } from "reactstrap";
import GrapheOperation2 from "components/GrapheOperation2";
// reactstrap components
import { Card, CardBody, CardFooter, CardTitle } from "reactstrap";
import PieOperation2 from "components/PieOperation2";
import TablesOperation2 from "components/TablesOperation2";
import { kpisOperation2 } from "variables/charts.js";

const Operation2 = () => {
  return (
    <>
      <div className="content">
        <Row>
          <Col lg="6" md="12" sm="12">
            <GrapheOperation2 />
          </Col>
          <Col md="6">
            <Row>
              {kpisOperation2.map((kpi) => (
                <Col lg="6" md="6" sm="6">
                  <Card className="card-stats">
                    <CardBody>
                      <Row>
                        <Col md="4" xs="5">
                          <div className="icon-big text-center icon-warning">
                            <i className={kpi.bigIcon} />
                          </div>
                        </Col>
                        <Col md="8" xs="7">
                          <div className="numbers">
                            <p className="card-category">{kpi.title}</p>
                            <CardTitle tag="p">{kpi.number}</CardTitle>
                            <p />
                          </div>
                        </Col>
                      </Row>
                    </CardBody>
                    <CardFooter>
                      <hr />
                      <div className="stats">
                        <i class={kpi.smallIcon}></i>
                        {kpi.stats}
                      </div>
                    </CardFooter>
                  </Card>
                </Col>
              ))}
            </Row>
            <PieOperation2 />
          </Col>
        </Row>
        <TablesOperation2 />
      </div>
    </>
  );
};

export default Operation2;
