import React from "react";
import { Row, Col } from "reactstrap";
// reactstrap components
import PieOperation2 from "components/PieOperation2";
import PieOperation1 from "components/PieOperation1";
import { Card, CardBody, CardFooter, CardTitle } from "reactstrap";
import { kpisBilan } from "variables/charts";

const Bilan = () => {
  return (
    <>
      <div className="content">
        <Row>
          {kpisBilan.map((kpi) => (
            <Col lg="3" md="6" sm="6">
              <Card className="card-stats">
                <CardBody>
                  <Row>
                    <Col md="4" xs="5">
                      <div className="icon-big text-center icon-warning">
                        <i className={kpi.bigIcon} />
                      </div>
                    </Col>
                    <Col md="8" xs="7">
                      <div className="numbers">
                        <p className="card-category">{kpi.title}</p>
                        <CardTitle tag="p">{kpi.number}</CardTitle>
                        <p />
                      </div>
                    </Col>
                  </Row>
                </CardBody>
                <CardFooter>
                  <hr />
                  <div className="stats">
                    <i class={kpi.smallIcon}></i>
                    {kpi.stats}
                  </div>
                </CardFooter>
              </Card>
            </Col>
          ))}
        </Row>
        <Row>
          <Col md="6">
            <PieOperation2 />
          </Col>
          <Col md="6">
            <PieOperation1 />
          </Col>
        </Row>
      </div>
    </>
  );
};

export default Bilan;
