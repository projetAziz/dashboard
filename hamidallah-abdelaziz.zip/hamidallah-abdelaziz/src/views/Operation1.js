import React from "react";
import PieOperation1 from "components/PieOperation1";
import { Row, Col } from "reactstrap";
import GrapheOperation1 from "components/GrapheOperation1";
// reactstrap components
import { Card, CardBody, CardFooter, CardTitle } from "reactstrap";
import TablesOperation1 from "components/TablesOperation1";
import { kpisOperation1 } from "variables/charts";

const Operation1 = () => {
  return (
    <>
      <div className="content">
        <Row>
          <Col lg="6" md="12" sm="12">
            <GrapheOperation1 />
          </Col>
          <Col md="6">
            <Row>
              {kpisOperation1.map((kpi) => (
                <Col lg="6" md="6" sm="6">
                  <Card className="card-stats">
                    <CardBody>
                      <Row>
                        <Col md="4" xs="5">
                          <div className="icon-big text-center icon-warning">
                            <i className={kpi.bigIcon} />
                          </div>
                        </Col>
                        <Col md="8" xs="7">
                          <div className="numbers">
                            <p className="card-category">{kpi.title}</p>
                            <CardTitle tag="p">{kpi.number}</CardTitle>
                            <p />
                          </div>
                        </Col>
                      </Row>
                    </CardBody>
                    <CardFooter>
                      <hr />
                      <div className="stats">
                        <i class={kpi.smallIcon}></i>
                        {kpi.stats}
                      </div>
                    </CardFooter>
                  </Card>
                </Col>
              ))}
            </Row>
            <PieOperation1 />
          </Col>
        </Row>
        <TablesOperation1 />
      </div>
    </>
  );
};

export default Operation1;
