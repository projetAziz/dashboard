import React from "react";
import Indicateur1 from "components/Indicateur1";
import Indicateur2 from "components/Indicateur2";
import ReseauxSociaux from "components/ReseauxSociaux";
import GrapheWeb from "components/GrapheWeb";
import ChartVentes from "variables/ChartVentes";

function Dashboard() {
  return (
    <>
      <div className="content">
        <Indicateur1 />
        <Indicateur2 />
        <ReseauxSociaux />
        <GrapheWeb />
        <ChartVentes />
      </div>
    </>
  );
}

export default Dashboard;
