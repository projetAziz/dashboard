import React from "react";
import { Bar } from "react-chartjs-2";
import { faker } from "@faker-js/faker";

const ChartVentes = () => {
  const labels = [
    "2019-04",
    "2019-05",
    "2019-06",
    "2019-07",
    "2019-08",
    "2019-09",
    "2019-10",
    "2019-11",
    "2019-12",
    "2020-01",
    "2020-02",
    "2020-03",
    "2020-04",
    "2020-05",
    "2020-06",
  ];

  const data = {
    labels,
    datasets: [
      {
        label: "Ventes",
        data: labels.map(() =>
          faker.datatype.number([
            11440, 4600, 17210, 4208, 7998, 3566, 17288, 5094, 9604, 5788, 7514,
            9206, 9600, 9834, 5470,
          ])
        ),
        backgroundColor: "rgba(53, 162, 235, 0.5)",
      },
      {
        label: "Revenu",
        data: labels.map(() =>
          faker.datatype.number([
            9312, 5070, 1268, 3106, 8332, 3900, 12740, 7599, 7536, 7792, 8850,
            9206, 8520, 10104, 5740,
          ])
        ),
        backgroundColor: "rgba(255,0,0)",
      },
    ],
  };

  return <Bar data={data} />;
};

export default ChartVentes;
