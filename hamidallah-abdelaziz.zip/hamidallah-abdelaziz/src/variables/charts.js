const pieOperation1 = {
  percentage: ["Envoi 69%  ", "Ouverture 23%  ", "Clic 8%  "],
  data: (canvas) => {
    return {
      labels: [1, 2, 3],
      datasets: [
        {
          label: "Données Camember",
          pointRadius: 0,
          pointHoverRadius: 0,
          backgroundColor: ["#4acccd", "#fcc468", "#ef8157"],
          borderWidth: 0,
          data: [11822, 3684, 976],
        },
      ],
    };
  },
  options: {
    plugins: {
      legend: { display: false },
      tooltip: { enabled: false },
    },
    maintainAspectRatio: false,
    pieceLabel: {
      render: "percentage",
      fontColor: ["red"],
      precision: 2,
    },
    scales: {
      y: {
        ticks: {
          display: false,
        },
        grid: {
          drawBorder: false,
          display: false,
        },
      },
      x: {
        barPercentage: 1.6,
        grid: {
          drawBorder: false,
          display: false,
        },
        ticks: {
          display: false,
        },
      },
    },
  },
};

const pieOperation2 = {
  percentage: ["Envoi 75%  ", "Ouverture 17%  ", "Clic 8% "],
  data: (canvas) => {
    return {
      labels: [1, 2, 3],
      datasets: [
        {
          label: "Données Camember",
          pointRadius: 0,
          pointHoverRadius: 0,
          backgroundColor: ["#adb5bd", "#ffc107", "#fd7e14"],
          borderWidth: 0,
          data: [8450, 2142, 690],
        },
      ],
    };
  },
  options: {
    plugins: {
      legend: { display: false },
      tooltip: { enabled: false },
    },
    maintainAspectRatio: false,
    pieceLabel: {
      render: "percentage",
      fontColor: ["red"],
      precision: 2,
    },
    scales: {
      y: {
        ticks: {
          display: false,
        },
        grid: {
          drawBorder: false,
          display: false,
        },
      },
      x: {
        barPercentage: 1.6,
        grid: {
          drawBorder: false,
          display: false,
        },
        ticks: {
          display: false,
        },
      },
    },
  },
};

const ReseauxSociauxChart = {
  data: (canvas) => {
    return {
      labels: [
        "2018-09",
        "2018-10",
        "2018-11",
        "2018-12",
        "2019-01",
        "2019-02",
        "2019-03",
        "2019-04",
        "2019-05",
        "2019-06",
        "2019-07",
        "2019-08",
        "2019-09",
        "2019-10",
        "2019-1",
        "2019-12",
        "2020-01",
        "2020-02",
        "2020-03",
        "2020-04",
        "2020-05",
        "2020-06",
      ],
      datasets: [
        {
          data: [
            1032, 10539, 10896, 11158, 11520, 11843, 12212, 12544, 13280, 13828,
            14075, 14227, 14430, 14743, 14954, 15138, 15325, 15537, 15819,
            16122,
          ],
          fill: false,
          borderColor: "#fbc658",
          backgroundColor: "transparent",
          pointBorderColor: "#fbc658",
          pointRadius: 4,
          pointHoverRadius: 4,
          pointBorderWidth: 8,
          tension: 0.4,
        },
        {
          data: [
            6453, 6953, 7573, 8133, 8932, 9755, 10753, 11535, 12305, 13016,
            13694, 14414, 15180, 16009, 16934, 17739, 18753, 19712, 20751,
            22229, 23837, 25121,
          ],
          fill: false,
          borderColor: "#E498A5 ",
          backgroundColor: "transparent",
          pointBorderColor: "#E498A5 ",
          pointRadius: 4,
          pointHoverRadius: 4,
          pointBorderWidth: 8,
          tension: 0.4,
        },
        {
          data: [
            2115, 2184, 2250, 2267, 2318, 2342, 2392, 2404, 2426, 2441, 2453,
            2461, 2468, 2472, 2486, 2496, 2511, 2531, 2539,
          ],
          fill: false,
          borderColor: "#51CACF",
          backgroundColor: "transparent",
          pointBorderColor: "#51CACF",
          pointRadius: 4,
          pointHoverRadius: 4,
          pointBorderWidth: 8,
          tension: 0.4,
        },
      ],
    };
  },
  options: {
    plugins: {
      legend: { display: false },
    },
  },
};
const grapheWebChart = {
  data: (canvas) => {
    return {
      labels: [
        "2018-09",
        "2018-10",
        "2018-11",
        "2018-12",
        "2019-01",
        "2019-02",
        "2019-03",
        "2019-04",
        "2019-05",
        "2019-06",
        "2019-07",
        "2019-08",
        "2019-09",
        "2019-10",
        "2019-1",
        "2019-12",
        "2020-01",
        "2020-02",
        "2020-03",
        "2020-04",
        "2020-05",
        "2020-06",
      ],
      datasets: [
        {
          data: [
            19085, 22377, 22259, 26086, 18153, 15027, 15155, 20642, 22708,
            19498, 19058, 19494, 19565, 25253, 24761, 18622, 15266,
          ],
          fill: false,
          borderColor: "#6609ff",
          backgroundColor: "transparent",
          pointBorderColor: "#6609ff",
          pointRadius: 4,
          pointHoverRadius: 4,
          pointBorderWidth: 8,
          tension: 0.4,
        },
        {
          data: [
            10473, 13572, 15049, 13486, 12945, 10197, 9907, 11367, 13389, 11991,
            10534, 10044, 9874, 12384, 12073, 8558, 6961,
          ],
          fill: false,
          borderColor: "#00ffff",
          backgroundColor: "transparent",
          pointBorderColor: "#00ffff",
          pointRadius: 4,
          pointHoverRadius: 4,
          pointBorderWidth: 8,
          tension: 0.4,
        },
      ],
    };
  },
  options: {
    plugins: {
      legend: { display: false },
    },
  },
};

const kpisOperation2 = [
  {
    bigIcon: "nc-icon nc-email-85 text-danger",
    title: "Ventes",
    number: " 50	",
    stats: "50 nouveaux ventes",
    smallIcon: "fas fa-chart-line",
  },
  {
    bigIcon: "nc-icon nc-money-coins text-success",
    title: "CA",
    number: "$ 3950",
    stats: "CA Mensuel",
    smallIcon: "fas fa-chart-line",
  },
];
const kpisOperation1 = [
  {
    bigIcon: "nc-icon nc-email-85 text-danger",
    title: "Ventes",
    number: " 78	",
    stats: "78 nouveaux ventes",
    smallIcon: "fas fa-chart-line",
  },
  {
    bigIcon: "nc-icon nc-money-coins text-success",
    title: "CA",
    number: "$ 5382",
    stats: "CA Mensuel",
    smallIcon: "fas fa-chart-line",
  },
];

const kpisIndicateur1 = [
  {
    bigIcon: "nc-icon nc-money-coins text-success",
    title: "Revenu",
    number: " $ 5,400	",
    stats: "Revenu Mensuel",
    smallIcon: "fas fa-chart-line",
  },
  {
    bigIcon: "nc-icon nc-email-85 text-danger",
    title: "Abonnés AC",
    number: " 10,375",
    stats: "150 nouveaux contacts",
    smallIcon: "fas fa-chart-line",
  },
  {
    bigIcon: "nc-icon nc-globe text-warning",
    title: "Visiteurs",
    number: "23 000",
    stats: "+42 Visiteurs",
    smallIcon: "fas fa-chart-line",
  },
  {
    bigIcon: "nc-icon nc-single-copy-04 text-primary",
    title: "Visites",
    number: "40 000",
    stats: "-541 visites",
    smallIcon: "fas fa-sort-amount-down",
  },
];

const kpisIndicateur2 = [
  {
    bigIcon: "fab fa-linkedin text-info",
    title: "Contacts LinkedIn",
    number: " 23 000	",
    stats: "42 Nouveaux Abonnés",
    smallIcon: "fas fa-chart-line",
  },
  {
    bigIcon: "fab fa-instagram text-danger",
    title: "Instagram",
    number: "589",
    stats: "541 Nouveaux Abonnés",
    smallIcon: "fas fa-chart-line",
  },
  {
    bigIcon: "fab fa-facebook text-primary",
    title: "Abonnés FB",
    number: "2 451",
    stats: "548 Nouveaux Abonnés",
    smallIcon: "fas fa-chart-line",
  },
  {
    bigIcon: "fab fa-youtube text-danger",
    title: "Abonnés YT",
    number: "5 400",
    stats: "457 Nouveaux Abonnés",
    smallIcon: "fas fa-chart-line",
  },
];

const kpisBilan = [
  {
    bigIcon: "nc-icon nc-email-85 text-danger",
    title: "Ventes",
    number: " 36	",
    stats: "36 nouveaux ventes",
    smallIcon: "fas fa-chart-line",
  },
  {
    bigIcon: "nc-icon nc-money-coins text-success",
    title: "CA",
    number: "$ 1712",
    stats: "CA Mensuel",
    smallIcon: "fas fa-chart-line",
  },
  {
    bigIcon: "nc-icon nc-email-85 text-danger",
    title: "Ventes",
    number: " 42	",
    stats: "42 nouveaux ventes",
    smallIcon: "fas fa-chart-line",
  },
  {
    bigIcon: "nc-icon nc-money-coins text-success",
    title: "CA",
    number: "$ 2814",
    stats: "CA Mensuel",
    smallIcon: "fas fa-chart-line",
  },
];
module.exports = {
  pieOperation1,
  ReseauxSociauxChart,
  grapheWebChart,
  pieOperation2,
  kpisOperation2,
  kpisOperation1,
  kpisIndicateur1,
  kpisIndicateur2,
  kpisBilan,
};
