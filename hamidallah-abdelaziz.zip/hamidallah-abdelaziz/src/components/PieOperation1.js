import React from "react";
// react plugin used to create charts
import { Pie } from "react-chartjs-2";
// reactstrap components
import { Card, CardHeader, CardBody, CardFooter, CardTitle } from "reactstrap";
// core components
import { pieOperation1 } from "variables/charts.js";

const PieOperation1 = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle tag="h5">Opération 1</CardTitle>
        <p className="card-category">DICTION 2020-30</p>
      </CardHeader>
      <CardBody style={{ height: "266px" }}>
        <Pie data={pieOperation1.data} options={pieOperation1.options} />
      </CardBody>
      <CardFooter>
        <div className="legend">
          <i className="fa fa-circle text-primary" /> Envoi{" "}
          <i className="fa fa-circle text-warning" /> Ouverture{" "}
          <i className="fa fa-circle text-danger" /> Clic{" "}
        </div>
        <hr />
        <div className="stats">
          <i class="fas fa-percent"></i> {pieOperation1.percentage}
        </div>
      </CardFooter>
    </Card>
  );
};

export default PieOperation1;
