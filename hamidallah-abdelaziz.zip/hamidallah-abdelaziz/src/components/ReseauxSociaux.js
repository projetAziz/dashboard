import React from "react";
// react plugin used to create charts
import { Line, Pie } from "react-chartjs-2";
// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  CardFooter,
  CardTitle,
  Row,
  Col,
} from "reactstrap";
// core components
import { ReseauxSociauxChart } from "variables/charts.js";

const ReseauxSociaux = () => {
  return (
    <Row>
      <Col md="12">
        <Card className="card-chart">
          <CardHeader>
            <CardTitle tag="h5">NASDAQ: AAPL</CardTitle>
            <p className="card-category">Line Chart with Points</p>
          </CardHeader>
          <CardBody>
            <Line
              data={ReseauxSociauxChart.data}
              options={ReseauxSociauxChart.options}
              width={400}
              height={100}
            />
          </CardBody>
          <CardFooter>
            <div className="chart-legend">
              <i className="fa fa-circle text-primary" /> Facebook{" "}
              <i className="fa fa-circle text-warning" /> Active Camping{" "}
              <i className="fa fa-circle text-danger" /> Youtube
            </div>
            <hr />
            <div className="card-stats">
              <i className="fa fa-check" /> Data information certified
            </div>
          </CardFooter>
        </Card>
      </Col>
    </Row>
  );
};

export default ReseauxSociaux;
