import React from "react";
// react plugin used to create charts
import { Line, Pie } from "react-chartjs-2";
// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  CardFooter,
  CardTitle,
  Row,
  Col,
} from "reactstrap";
// core components
import { grapheWebChart } from "variables/charts.js";

const GrapheWeb = () => {
  return (
    <Row>
      <Col md="12">
        <Card className="card-chart">
          <CardHeader>
            <CardTitle tag="h5">Graphe mensuel Web</CardTitle>
            <p className="card-category">Visiteurs/ Pages Vues</p>
          </CardHeader>
          <CardBody>
            <Line
              data={grapheWebChart.data}
              options={grapheWebChart.options}
              width={400}
              height={100}
            />
          </CardBody>
          <CardFooter>
            <div className="chart-legend">
              <i className="fa fa-circle text-info" /> Visiteurs{" "}
              <i className="fa fa-circle text-warning" /> Pages Vues
            </div>
            <hr />
            <div className="card-stats">
              <i className="fa fa-check" /> Data information certified
            </div>
          </CardFooter>
        </Card>
      </Col>
    </Row>
  );
};

export default GrapheWeb;
