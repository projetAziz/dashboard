import {
  Card,
  CardHeader,
  CardBody,
  CardFooter,
  CardTitle,
  Row,
  Col,
} from "reactstrap";
import { kpisIndicateur1 } from "variables/charts";

const Indicateur1 = () => {
  return (
    <Row>
      {kpisIndicateur1.map((kpi) => (
        <Col lg="3" md="6" sm="6">
          <Card className="card-stats">
            <CardBody>
              <Row>
                <Col md="4" xs="5">
                  <div className="icon-big text-center icon-warning">
                    <i className={kpi.bigIcon} />
                  </div>
                </Col>
                <Col md="8" xs="7">
                  <div className="numbers">
                    <p className="card-category">{kpi.title}</p>
                    <CardTitle tag="p">{kpi.number}</CardTitle>
                    <p />
                  </div>
                </Col>
              </Row>
            </CardBody>
            <CardFooter>
              <hr />
              <div className="stats">
                <i class={kpi.smallIcon}></i>
                {kpi.stats}
              </div>
            </CardFooter>
          </Card>
        </Col>
      ))}
    </Row>
  );
};

export default Indicateur1;
