import React from "react";
import { Bar } from "react-chartjs-2";
import { faker } from "@faker-js/faker";

const GrapheOperation2 = () => {
  const labels = ["#1", "#1b", "#2", "#3", "#4", "#5", "#6", "#7"];

  const data = {
    labels,
    datasets: [
      {
        label: "Ventes",
        data: labels.map(() =>
          faker.datatype.number([1048, 958, 573, 853, 427, 625, 759, 0])
        ),
        backgroundColor: "#00ffff",
      },
      {
        label: "Revenu",
        data: labels.map(() =>
          faker.datatype.number([245, 154, 110, 104, 40, 60, 98, 0])
        ),
        backgroundColor: "#ffff00",
      },
    ],
  };

  return <Bar data={data} />;
};

export default GrapheOperation2;
