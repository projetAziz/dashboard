import React from "react";
import { Bar } from "react-chartjs-2";
import { faker } from "@faker-js/faker";

const GrapheOperation1 = () => {
  const labels = ["#1", "#1b", "#2", "#3", "#4", "#5", "#6", "#7"];

  const data = {
    labels,
    datasets: [
      {
        label: "Ventes",
        data: labels.map(() =>
          faker.datatype.number([1603, 919, 1676, 1451, 1331, 1946, 0, 0])
        ),
        backgroundColor: "#0000ff",
      },
      {
        label: "Revenu",
        data: labels.map(() =>
          faker.datatype.number([256, 124, 208, 130, 200, 268, 0, 0])
        ),
        backgroundColor: "#24ff38",
      },
    ],
  };

  return <Bar data={data} />;
};

export default GrapheOperation1;
