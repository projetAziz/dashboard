import React from "react";
import JsonData from "./tableOperation1.json";

// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Row,
  Table,
  Col,
} from "reactstrap";

const TablesOperation1 = () => {
  return (
    <Row>
      <Col md="12">
        <Card>
          <CardHeader>
            <CardTitle tag="h4">Diction 2020-03</CardTitle>
          </CardHeader>
          <CardBody>
            <Table responsive>
              <thead className="text-primary">
                <tr>
                  <th></th>
                  <th></th>
                  <th>SUJET</th>
                  <th className="text-right">Envoi</th>
                  <th>Ouv</th>
                  <th></th>
                  <th>Clics</th>
                  <th className="text-right"></th>
                  <th>Ventes</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {JsonData.map((info) => (
                  <tr>
                    <td>{info.number}</td>
                    <td>{info.Date}</td>
                    <td>{info.SUJET}</td>
                    <td>{info.Envoi}</td>
                    <td>{info.Ouv}</td>
                    <td className="text-right">{info.porcOuv}</td>
                    <td className="text-right">{info.Clics}</td>
                    <td className="text-right">{info.pourClic}</td>
                    <td className="text-right">{info.Ventes}</td>
                    <td className="text-right">{info.porcentage}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </CardBody>
        </Card>
      </Col>
    </Row>
  );
};
export default TablesOperation1;
