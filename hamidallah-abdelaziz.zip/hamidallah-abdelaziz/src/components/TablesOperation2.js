import React from "react";
import JsonData from "./tableOperation2.json";

// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Row,
  Table,
  Col,
} from "reactstrap";

const TablesOperation2 = () => {
  return (
    <Row>
      <Col md="12">
        <Card>
          <CardHeader>
            <CardTitle tag="h4">Diction 2020-03</CardTitle>
          </CardHeader>
          <CardBody>
            <Table responsive>
              <thead className="text-primary">
                <tr>
                  <th></th>
                  <th></th>
                  <th>SUJET</th>
                  <th>Envoi</th>
                  <th>Ouv</th>
                  <th></th>
                  <th>Clics</th>
                  <th></th>
                  <th>Ventes</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {JsonData.map((info) => (
                  <tr>
                    <td>{info.number}</td>
                    <td>{info.date}</td>
                    <td>{info.SUJET}</td>
                    <td>{info.Envoi}</td>
                    <td>{info.Ouv}</td>
                    <td>{info.OuvPorcentage}</td>
                    <td>{info.Clics}</td>
                    <td>{info.ClickPorcentage}</td>
                    <td>{info.Ventes}</td>
                    <td className="text-right">{info.Porcentage}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </CardBody>
        </Card>
      </Col>
    </Row>
  );
};
export default TablesOperation2;
